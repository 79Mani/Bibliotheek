package org.example;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.testng.AssertJUnit.assertEquals;

public class KlantTest {
    private Klant klant;

    @Before
    public void setUp() {
        klant = new Klant("Naam", 1);
    }

    @Test
    public void testGetNaam() {
        assertEquals("Naam", klant.getNaam());
    }

    @Test
    public void testGetKlantId() {
        assertEquals(1, klant.getKlantId());
    }

    @Test
    public void testLeenBoekUit() {
        Boek boek = new Boek("Titel", "Auteur");
        klant.leenBoekUit(boek);
        assertTrue(klant.getGeleendeBoeken().contains(boek));
    }

    @Test
    public void testRetourneerBoek() {
        Boek boek = new Boek("Titel", "Auteur");
        klant.leenBoekUit(boek);
        klant.retourneerBoek(boek);
        assertFalse(klant.getGeleendeBoeken().contains(boek));
    }

}
