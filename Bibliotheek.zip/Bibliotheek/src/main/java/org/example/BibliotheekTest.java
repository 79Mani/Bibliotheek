package org.example;

import org.junit.Before;
import org.junit.Test;
import org.junit.Assert;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.testng.AssertJUnit.assertEquals;


public class BibliotheekTest {
    private Bibliotheek bibliotheek;
    private Boek boek1;
    private Boek boek2;
    private Klant klant1;

    @Before
    public void setUp() {
        bibliotheek = new Bibliotheek();
        boek1 = new Leerboek("Programmeren in Java", "John Doe", "Informatica");
        boek2 = new Verhaalboek("De Da Vinci Code", "Dan Brown", "Mysterie");
        klant1 = new Klant("Alice", 1);
    }

    @Test
    public void testVoegBoekToe() {
        bibliotheek.voegBoekToe(boek1);
        bibliotheek.voegBoekToe(boek2);

        List<Boek> beschikbareBoeken = bibliotheek.getBeschikbareBoeken();

        assertTrue(beschikbareBoeken.contains(boek1));
        assertTrue(beschikbareBoeken.contains(boek2));
    }

    @Test
    public void testLeenBoekUit() {
        bibliotheek.voegBoekToe(boek1);
        bibliotheek.voegBoekToe(boek2);

        bibliotheek.leenBoekUit(boek1, klant1);

        List<Boek> beschikbareBoeken = bibliotheek.getBeschikbareBoeken();
        List<Boek> uitgeleendeBoeken = bibliotheek.getUitgeleendeBoeken();
        List<Boek> geleendeBoekenVanKlant = klant1.getGeleendeBoeken();

        assertFalse(beschikbareBoeken.contains(boek1));
        assertTrue(uitgeleendeBoeken.contains(boek1));
        assertTrue(geleendeBoekenVanKlant.contains(boek1));
    }

    @Test
    public void testRetourneerBoek() {
        bibliotheek.voegBoekToe(boek1);
        bibliotheek.voegBoekToe(boek2);

        bibliotheek.leenBoekUit(boek1, klant1);
        bibliotheek.retourneerBoek(boek1, klant1);

        List<Boek> beschikbareBoeken = bibliotheek.getBeschikbareBoeken();
        List<Boek> uitgeleendeBoeken = bibliotheek.getUitgeleendeBoeken();
        List<Boek> geleendeBoekenVanKlant = klant1.getGeleendeBoeken();

        assertTrue(beschikbareBoeken.contains(boek1));
        assertFalse(uitgeleendeBoeken.contains(boek1));
        assertFalse(geleendeBoekenVanKlant.contains(boek1));
    }
}
