package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;







class Bibliotheek {
    private List<Boek> beschikbareBoeken;
    private List<Boek> uitgeleendeBoeken;



    private List<Klant> klantenlijst;

    public List<Klant> getKlantenlijst() {
        return klantenlijst;
    }
    public void printBoeken(List<Boek> boekenlijst){
        for (Boek boek: boekenlijst) {
            System.out.println("Titel: " + boek.getTitel() +  " auteur: " + boek.getAuteur());
        }
    }
    public Bibliotheek() {
        beschikbareBoeken = new ArrayList<>();
        uitgeleendeBoeken = new ArrayList<>();
        klantenlijst = new ArrayList<>();
    }

    public List<Boek> getBeschikbareBoeken() {
        return beschikbareBoeken;
    }

    public List<Boek> getUitgeleendeBoeken() {
        return uitgeleendeBoeken;
    }



    public void voegBoekToe(Boek boek) {
        beschikbareBoeken.add(boek);
    }

    public void leenBoekUit(Boek boek, Klant klant) {
        if (beschikbareBoeken.contains(boek)) {
            beschikbareBoeken.remove(boek);
            uitgeleendeBoeken.add(boek);
            klant.leenBoekUit(boek);
        } else {
            System.out.println("Het boek is niet beschikbaar in de bibliotheek.");
        }
    }

    public void retourneerBoek(Boek boek, Klant klant) {
        if (uitgeleendeBoeken.contains(boek)) {
            uitgeleendeBoeken.remove(boek);
            beschikbareBoeken.add(boek);
            klant.retourneerBoek(boek);
        } else {
            System.out.println("Het boek is niet uitgeleend aan deze klant.");
        }
    }
}



class Boek {
    private String titel;
    private String auteur;





    public Boek(String titel, String auteur) {
        this.titel = titel;
        this.auteur = auteur;
    }


    public String getTitel() {
        return titel;
    }

    public String getAuteur() {
        return auteur;
    }






}

class Klant {
    private String naam;
    private int klantId;
    private List<Boek> geleendeBoeken;

    public Klant(String naam, int klantId) {
        this.naam = naam;
        this.klantId = klantId;
        geleendeBoeken = new ArrayList<>();
    }



    public String getNaam() {
        return naam;
    }

    public int getKlantId() {
        return klantId;
    }

    public void printGeleendeBoeken(List<Boek> boekenlijst){
        for (Boek boek: boekenlijst
             ) {
            System.out.println("Titel: " + boek.getTitel() +  " auteur: " + boek.getAuteur());

        }
    }

    public List<Boek> getGeleendeBoeken() {
        return geleendeBoeken;
    }

    public void leenBoekUit(Boek boek) {
        geleendeBoeken.add(boek);
    }

    public void retourneerBoek(Boek boek) {
        geleendeBoeken.remove(boek);
    }
}

class Leerboek extends Boek {
    private String vakgebied;

    public Leerboek(String titel, String auteur,String vakgebied) {
        super(titel, auteur);
        this.vakgebied = vakgebied;
    }

    public String getVakgebied() {
        return vakgebied;
    }


}

class Verhaalboek extends Boek {
    private String genre;

    public Verhaalboek(String titel, String auteur, String genre) {
        super(titel, auteur);
        this.genre = genre;

    }

    public String getGenre() {
        return genre;
    }


}

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Bibliotheek bibliotheek = new Bibliotheek();


        Boek boek1 = new Leerboek("Programmeren in Java", "John Doe", "Informatica");
        Boek boek2 = new Verhaalboek("De Da Vinci Code", "Dan Brown", "Mysterie");
        Boek boek3 = new Verhaalboek("Harry Potter en de Steen der Wijzen", "J.K. Rowling", "Fantasy");
        Boek boek4 = new Verhaalboek("aapjes", "A", "Fantasy");

        bibliotheek.voegBoekToe(boek1);
        bibliotheek.voegBoekToe(boek2);
        bibliotheek.voegBoekToe(boek3);
        bibliotheek.voegBoekToe(boek4);

        Klant klant1 = new Klant("Jan Jansen", 1);


        bibliotheek.leenBoekUit(boek2, klant1);
        bibliotheek.leenBoekUit(boek3, klant1);
        bibliotheek.leenBoekUit(boek1, klant1);

        System.out.println("Beschikbare boeken: ");
        bibliotheek.printBoeken(bibliotheek.getBeschikbareBoeken());
        System.out.println("Boeken van klant 1:");
        bibliotheek.printBoeken(klant1.getGeleendeBoeken());
        System.out.println("Boeken van klant 2:");
        bibliotheek.printBoeken(klant1.getGeleendeBoeken());

        bibliotheek.retourneerBoek(boek2, klant1);

        System.out.println("Beschikbare boeken na retourneren: ");
        bibliotheek.printBoeken(bibliotheek.getBeschikbareBoeken());
        System.out.println("Uitgeleende boeken na retourneren: ");
        bibliotheek.printBoeken(bibliotheek.getUitgeleendeBoeken());

        System.out.println("Boeken van klant 1 na retourneren: ");
        bibliotheek.printBoeken(klant1.getGeleendeBoeken());
        System.out.println("Boeken van klant 2 na retourneren: ");
        bibliotheek.printBoeken(klant1.getGeleendeBoeken());


        boolean klaar = false;
        while (!klaar) {

                System.out.println("Wat wilt U doen kies 1,2 of 3:");
                System.out.println("1: Een boek lenen");
                System.out.println("2: Een Boek terug brengen");
                System.out.println("3: Stoppen");
                int antwoord = input.nextInt();
                if (antwoord == 1) {
                    System.out.println("welk boek wilt u lenen? kies een nummer tussen 1 en " + bibliotheek.getBeschikbareBoeken().size());
                    bibliotheek.printBoeken(bibliotheek.getBeschikbareBoeken());
                    int boeknummer = input.nextInt();
                    bibliotheek.leenBoekUit(bibliotheek.getBeschikbareBoeken().get(boeknummer - 1),klant1);
                    System.out.println("Dit zijn de boeken die U nu leent: " );
                    bibliotheek.printBoeken(klant1.getGeleendeBoeken());
                }


                else if (antwoord == 2) {
                    System.out.println("welk boek wilt u terugbrengen? kies een nummer tussen 1 en " + bibliotheek.getUitgeleendeBoeken().size());
                    bibliotheek.printBoeken(bibliotheek.getUitgeleendeBoeken());
                    int boeknummer = input.nextInt();
                    bibliotheek.retourneerBoek(bibliotheek.getUitgeleendeBoeken().get(boeknummer - 1),klant1);
                    System.out.println("Dit zijn de boeken die U nu leent: " );
                    bibliotheek.printBoeken(klant1.getGeleendeBoeken());
                }
                else klaar = true;

            }
        }
    }



