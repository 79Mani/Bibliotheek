package org.example;

import org.junit.Before;
import org.junit.Test;

import static org.testng.AssertJUnit.assertEquals;

public class BoekTest {
    private Boek boek;

    @Before
    public void setUp() {
        boek = new Boek("Titel", "Auteur");
    }

    @Test
    public void testGetTitel() {
        assertEquals("Titel", boek.getTitel());
    }

    @Test
    public void testGetAuteur() {
        assertEquals("Auteur", boek.getAuteur());
    }


}
